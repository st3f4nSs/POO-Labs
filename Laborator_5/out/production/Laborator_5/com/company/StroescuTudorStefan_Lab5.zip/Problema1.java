/**
 *
 * @author Nan Mihai
 */
package com.company;

class Animal {
    private String nume;
    private String culoare;

    static {
        System.out.println("Bloc 2 - Animal");
    }

    {
        System.out.println("Bloc 1 - Animal");
        nume = "Animal";
        culoare = "negru";
    }
    public String getCuloare() {
        return culoare;
    }
}

class Caine extends Animal {
    private String tipRasa;

    static {
        System.out.println("Bloc 2 - Caine");
    }

    {
        tipRasa = "medie";
        System.out.println("Bloc 1 - Caine " + getCuloare());
    }

    {
        System.out.println("Bloc 4 - Caine");
        tipRasa = "mica";
    }

    {
        System.out.println("Bloc 3 - Caine");
        tipRasa = "mare";
    }
}

class SharPei extends Caine {
    private int varsta;
    private static String taraProvenienta;

    static {
        System.out.println("Bloc 1 - SharPei");
        taraProvenienta = "China";
    }

    static {
        System.out.println("Bloc 2 - SharPei " + taraProvenienta);
    }

    {
        varsta = 5;
        System.out.println("Bloc 3 - SharPei " + varsta);
    }
}

class Problema1 {
    public static void main(String args[]) {
        SharPei cutu = new SharPei();
    }
}